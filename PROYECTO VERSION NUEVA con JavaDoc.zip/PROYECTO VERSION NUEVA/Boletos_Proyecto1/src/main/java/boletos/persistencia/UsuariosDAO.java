package boletos.persistencia;

import boletos.dtos.ActualizarUsuarioDTO;
import boletos.dtos.UsuarioDTO;
import boletos.entidades.Usuario;
import java.sql.*;

/**
 * Clase de acceso a datos (DAO) para la gestión de usuarios en la base de datos.
 * Proporciona métodos para obtener, registrar, actualizar y obtener el saldo de los usuarios.
 */
public class UsuariosDAO {

    private final ConexionBD manejadorConexiones;

    /**
     * Constructor que inicializa el manejador de conexiones a la base de datos.
     * 
     * @param manejadorConexiones Objeto que maneja las conexiones a la base de datos.
     */
    public UsuariosDAO(ConexionBD manejadorConexiones) {
        this.manejadorConexiones = manejadorConexiones;
    }

    /**
     * Obtiene un usuario de la base de datos por su ID.
     * 
     * @param id ID del usuario a consultar.
     * @return Un objeto UsuarioDTO que representa los datos del usuario o null si no se encuentra.
     */
    public UsuarioDTO obtenerUsuarioPorID(Integer id) {
        String sql = "SELECT * FROM Usuarios WHERE idUsuario = ?";
        try (Connection conn = manejadorConexiones.crearConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new UsuarioDTO(
                        rs.getInt("idUsuario"),
                        rs.getString("email"),
                        rs.getString("nombre"),
                        rs.getString("contraseña_hash"),
                        rs.getDouble("saldo"),
                        rs.getInt("IdDireccion")
                );
            }
        } catch (SQLException e) {
            System.err.println("No se pudo obtener el usuario: " + e);
        }
        return null;
    }

    /**
     * Agrega saldo a un usuario en la base de datos.
     * 
     * @param id ID del usuario al que se le va a agregar el saldo.
     * @param saldo Cantidad de saldo a agregar.
     * @return true si el saldo fue agregado correctamente, false en caso de error.
     */
    public boolean agregarSaldoUsuario(Integer id, Double saldo) {
        String sql = "call AÑADIR_SALDO(?,?);";
        try (Connection conn = manejadorConexiones.crearConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.setDouble(2, saldo);
            boolean exito = stmt.execute(); // Ejecuta el procedimiento

            return true; // Si no hubo errores, asumimos que se ejecutó correctamente
            //regresa true si se realizo
        } catch (SQLException e) {
            System.err.println("No se pudo añadir el saldo: " + e);
            return false;
        }
    }

    /**
     * Obtiene el saldo de un usuario utilizando su objeto UsuarioDTO.
     * 
     * @param usuario Objeto UsuarioDTO que contiene la información del usuario.
     * @return El saldo actual del usuario.
     */
    public double obtenerSaldoUsuario(UsuarioDTO usuario) {
        String sql = "SELECT saldo FROM Usuarios WHERE idUsuario = ?";
        try (Connection conn = manejadorConexiones.crearConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, usuario.getIdUsuario());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble("saldo"); // Retorna el saldo actualizado
            }
        } catch (SQLException e) {
            System.err.println("Error obteniendo el saldo: " + e.getMessage());
        }
        return 0.0;
    }

    /**
     * Registra un nuevo usuario en la base de datos.
     * 
     * @param usuario Objeto Usuario que contiene los datos del nuevo usuario.
     * @return true si el usuario fue registrado correctamente, false en caso de error.
     */
    public boolean registrarUsuario(Usuario usuario) {
        String sql = "CALL registrar_usuario(?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = manejadorConexiones.crearConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, usuario.getEmail());
            stmt.setString(2, usuario.getNombre());
            stmt.setString(3, usuario.getContrasena()); // Contraseña ya en hash
            stmt.setString(4, usuario.getApellidoPaterno());
            stmt.setString(5, usuario.getApellidoMaterno());
            stmt.setDate(6, Date.valueOf(usuario.getFechaNacimiento()));
            stmt.setString(7, usuario.getDireccion().getCalle());
            stmt.setString(8, usuario.getDireccion().getCiudad());
            stmt.setString(9, usuario.getDireccion().getEstado());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al registrar usuario: " + e.getMessage());
            return false;
        }
    }

     /**
     * Obtiene el ID de un usuario utilizando su email.
     * 
     * @param email Email del usuario.
     * @return El ID del usuario, o null si no se encuentra.
     */
    public Integer obtenerIdPorEmail(String email) {
        String sql = "SELECT idUsuario FROM Usuarios WHERE email = ?";
        try (Connection conn = manejadorConexiones.crearConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("idUsuario");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // Retorna null si no encuentra el usuario
    }

    /**
     * Actualiza los datos de un usuario en la base de datos.
     * 
     * @param idUsuario ID del usuario a actualizar.
     * @param actualizarUsuario Objeto ActualizarUsuarioDTO con los nuevos datos del usuario.
     * @param idDireccion ID de la dirección del usuario.
     */
    public void actualizarUsuario(Integer idUsuario, ActualizarUsuarioDTO actualizarUsuario, Integer idDireccion) {

        String codigoSQL = """
                    CALL ActualizarUsuario(?,?,?,?,?,?,?,?,?,?,?);
                    """;

        try {
            Connection conexion = manejadorConexiones.crearConexion();
            PreparedStatement comando = conexion.prepareCall(codigoSQL);
            comando.setInt(1, idUsuario);
            comando.setInt(2, idDireccion);
            comando.setString(3, actualizarUsuario.getEmail());
            comando.setString(4, actualizarUsuario.getNombre());
            comando.setString(5, actualizarUsuario.getApellidoPaterno());
            comando.setString(6, actualizarUsuario.getApellidoMaterno());
            comando.setString(7, actualizarUsuario.getFechaNacimiento());
            comando.setString(8, actualizarUsuario.getCalle());
            comando.setString(9, actualizarUsuario.getCiudad());
            comando.setString(10, actualizarUsuario.getEstado());
            comando.setString(11, actualizarUsuario.getHash_contrasena());

            comando.execute();

        } catch (SQLException ex) {
            System.err.println("Error al actulizar el usuario: " + ex.getMessage());
        }
    }

}
