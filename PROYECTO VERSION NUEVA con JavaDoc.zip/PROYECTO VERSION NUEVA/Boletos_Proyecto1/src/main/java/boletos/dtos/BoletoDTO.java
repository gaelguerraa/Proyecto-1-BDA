/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package boletos.dtos;

import java.sql.Timestamp;

/**
 * DTO (Data Transfer Object) para representar la información de un boleto.
 * Este objeto es utilizado para transferir los datos de un boleto, como su número de serie,
 * precio, estado, evento relacionado y fecha de emisión.
 */
public class BoletoDTO {
    
    private Integer idBoleto;
    private String numSerie;
    private String fila;
    private String asiento;
    private Double precio;
    private String estado;
    private String evento;
    private Timestamp fecha;

    /**
     * Constructor de la clase BoletoDTO.
     * @param idBoleto El ID único del boleto.
     * @param numSerie El número de serie del boleto.
     * @param fila La fila asignada al boleto.
     * @param asiento El asiento asignado al boleto.
     * @param precio El precio del boleto.
     * @param estado El estado del boleto (ej. disponible, vendido, etc.).
     * @param evento El nombre o tipo de evento relacionado con el boleto.
     * @param fecha La fecha de emisión del boleto.
     */
    public BoletoDTO(Integer idBoleto, String numSerie, String fila, String asiento, Double precio, String estado, String evento, Timestamp fecha) {
        this.idBoleto = idBoleto;
        this.numSerie = numSerie;
        this.fila = fila;
        this.asiento = asiento;
        this.precio = precio;
        this.estado = estado;
        this.evento = evento;
        this.fecha = fecha;
    }

    /**
     * Obtiene el ID del boleto.
     * @return El ID del boleto.
     */
    public Integer getIdBoleto() {
        return idBoleto;
    }

    /**
     * Obtiene el número de serie del boleto.
     * @return El número de serie del boleto.
     */
    public String getNumSerie() {
        return numSerie;
    }

    /**
     * Obtiene la fila asignada al boleto.
     * @return La fila del boleto.
     */
    public String getFila() {
        return fila;
    }

    /**
     * Obtiene el asiento asignado al boleto.
     * @return El asiento del boleto.
     */
    public String getAsiento() {
        return asiento;
    }

    /**
     * Obtiene el precio del boleto.
     * @return El precio del boleto.
     */
    public Double getPrecio() {
        return precio;
    }

    /**
     * Obtiene el estado del boleto.
     * @return El estado del boleto (ej. disponible, vendido, etc.).
     */
    public String getEstado() {
        return estado;
    }

    /**
     * Obtiene el evento relacionado con el boleto.
     * @return El evento asociado al boleto.
     */
    public String getEvento() {
        return evento;
    }

    /**
     * Obtiene la fecha de emisión del boleto.
     * @return La fecha de emisión del boleto.
     */
    public Timestamp getFecha() {
        return fecha;
    }
    
}
