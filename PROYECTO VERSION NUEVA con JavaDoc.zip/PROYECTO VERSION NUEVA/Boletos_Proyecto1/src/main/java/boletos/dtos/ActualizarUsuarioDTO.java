package boletos.dtos;

/**
 * DTO (Data Transfer Object) para actualizar los datos del usuario.
 * Este objeto es utilizado para transferir información relacionada con el usuario
 * que se desea actualizar.
 */
public class ActualizarUsuarioDTO {
    
    private Integer idUsuario;
    private String email;
    private String nombre;
    private String hash_contrasena;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String fechaNacimiento;
    private String calle;
    private String ciudad;
    private String estado;

    /**
     * Constructor de la clase ActualizarUsuarioDTO.
     * @param email El correo electrónico del usuario.
     * @param nombre El nombre del usuario.
     * @param apellidoPaterno El apellido paterno del usuario.
     * @param apellidoMaterno El apellido materno del usuario.
     * @param fechaNacimiento La fecha de nacimiento del usuario.
     * @param calle La calle del domicilio del usuario.
     * @param ciudad La ciudad del domicilio del usuario.
     * @param estado El estado del domicilio del usuario.
     * @param hash_contrasena El hash de la contraseña del usuario.
     */
    public ActualizarUsuarioDTO( String email, String nombre, String apellidoPaterno, String apellidoMaterno, String fechaNacimiento, String calle, String ciudad, String estado, String hash_contrasena) {
        
        this.email = email;
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.fechaNacimiento = fechaNacimiento;
        this.calle = calle;
        this.ciudad = ciudad;
        this.estado = estado;
        this.hash_contrasena = hash_contrasena;
    }

    /**
     * Obtiene el ID del usuario.
     * @return El ID del usuario.
     */
    public Integer getIdUsuario() {
        return idUsuario;
    }

    /**
     * Obtiene el correo electrónico del usuario.
     * @return El correo electrónico del usuario.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Obtiene el nombre del usuario.
     * @return El nombre del usuario.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Obtiene el hash de la contraseña del usuario.
     * @return El hash de la contraseña del usuario.
     */
    public String getHash_contrasena() {
        return hash_contrasena;
    }

    /**
     * Obtiene el apellido paterno del usuario.
     * @return El apellido paterno del usuario.
     */
    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    /**
     * Obtiene el apellido materno del usuario.
     * @return El apellido materno del usuario.
     */
    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    /**
     * Obtiene la fecha de nacimiento del usuario.
     * @return La fecha de nacimiento del usuario.
     */
    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    /**
     * Obtiene la calle del domicilio del usuario.
     * @return La calle del domicilio del usuario.
     */
    public String getCalle() {
        return calle;
    }

    /**
     * Obtiene la ciudad del domicilio del usuario.
     * @return La ciudad del domicilio del usuario.
     */
    public String getCiudad() {
        return ciudad;
    }

    /**
     * Obtiene el estado del domicilio del usuario.
     * @return El estado del domicilio del usuario.
     */
    public String getEstado() {
        return estado;
    }
    
}
