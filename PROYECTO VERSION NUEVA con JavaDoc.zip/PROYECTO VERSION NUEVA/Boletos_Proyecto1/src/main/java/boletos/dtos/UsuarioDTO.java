package boletos.dtos;

/**
 * Clase DTO que representa a un usuario.
 * Contiene los detalles de un usuario, incluyendo su identificación, email, nombre,
 * contraseña (hash), saldo y dirección.
 * 
 * @author gael_
 */
public class UsuarioDTO {

    private int idUsuario;
    private String email;
    private String nombre;
    private String hashContraseña;
    private double saldo;
    private int idDireccion;

    /**
     * Constructor que inicializa un nuevo objeto UsuarioDTO con los valores proporcionados.
     * 
     * @param idUsuario El ID del usuario.
     * @param email El email del usuario.
     * @param nombre El nombre del usuario.
     * @param hashContraseña El hash de la contraseña del usuario.
     * @param saldo El saldo disponible del usuario.
     * @param idDireccion El ID de la dirección del usuario.
     */
    public UsuarioDTO(int idUsuario, String email, String nombre, String hashContraseña, double saldo, int idDireccion) {
        this.idUsuario = idUsuario;
        this.email = email;
        this.nombre = nombre;
        this.hashContraseña = hashContraseña;
        this.saldo = saldo;
        this.idDireccion = idDireccion;
    }

    /**
     * Obtiene el ID del usuario.
     * 
     * @return El ID del usuario.
     */
    public int getIdUsuario() {
        return idUsuario;
    }

    /**
     * Obtiene el email del usuario.
     * 
     * @return El email del usuario.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Obtiene el nombre del usuario.
     * 
     * @return El nombre del usuario.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Obtiene el hash de la contraseña del usuario.
     * 
     * @return El hash de la contraseña del usuario.
     */
    public String getHashContraseña() {
        return hashContraseña;
    }

    /**
     * Obtiene el saldo disponible del usuario.
     * 
     * @return El saldo disponible del usuario.
     */
    public double getSaldo() {
        return saldo;
    }

    /**
     * Obtiene el ID de la dirección del usuario.
     * 
     * @return El ID de la dirección del usuario.
     */
    public int getIdDireccion() {
        return idDireccion;
    }
}

