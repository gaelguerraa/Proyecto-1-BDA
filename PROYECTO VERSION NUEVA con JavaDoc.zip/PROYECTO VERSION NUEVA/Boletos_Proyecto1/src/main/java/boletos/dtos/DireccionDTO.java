package boletos.dtos;

/**
 * DTO (Data Transfer Object) para representar la información de una dirección.
 * Este objeto es utilizado para transferir los datos relacionados con una dirección, 
 * como su ID, calle, ciudad y estado.
 */
public class DireccionDTO {
    
    private Integer idDireccion;
    private String calle;
    private String ciudad;
    private String estado;

    /**
     * Constructor de la clase DireccionDTO.
     * @param idDireccion El ID único de la dirección.
     * @param calle La calle de la dirección.
     * @param ciudad La ciudad de la dirección.
     * @param estado El estado de la dirección.
     */
    public DireccionDTO(Integer idDireccion, String calle, String ciudad, String estado) {
        this.idDireccion = idDireccion;
        this.calle = calle;
        this.ciudad = ciudad;
        this.estado = estado;
    }

    /**
     * Obtiene el ID de la dirección.
     * @return El ID de la dirección.
     */
    public Integer getIdDireccion() {
        return idDireccion;
    }

    /**
     * Obtiene la calle de la dirección.
     * @return La calle de la dirección.
     */
    public String getCalle() {
        return calle;
    }

    /**
     * Obtiene la ciudad de la dirección.
     * @return La ciudad de la dirección.
     */
    public String getCiudad() {
        return ciudad;
    }

    /**
     * Obtiene el estado de la dirección.
     * @return El estado de la dirección.
     */
    public String getEstado() {
        return estado;
    }
    
}
