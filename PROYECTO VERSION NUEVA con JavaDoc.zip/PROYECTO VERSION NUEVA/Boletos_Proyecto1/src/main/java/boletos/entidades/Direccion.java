package boletos.entidades;

/**
 * Clase que representa una dirección.
 * Una dirección está compuesta por la calle, ciudad y estado.
 * 
 * @author gael_
 */
public class Direccion {
    private String calle;
    private String ciudad;
    private String estado;

    /**
     * Constructor que inicializa los atributos de la dirección.
     * 
     * @param calle La calle de la dirección.
     * @param ciudad La ciudad de la dirección.
     * @param estado El estado de la dirección.
     */
    public Direccion(String calle, String ciudad, String estado) {
        this.calle = calle;
        this.ciudad = ciudad;
        this.estado = estado;
    }

    /**
     * Obtiene la calle de la dirección.
     * 
     * @return La calle de la dirección.
     */
    public String getCalle() {
        return calle;
    }

    /**
     * Establece la calle de la dirección.
     * 
     * @param calle La calle de la dirección.
     */
    public void setCalle(String calle) {
        this.calle = calle;
    }

    /**
     * Obtiene la ciudad de la dirección.
     * 
     * @return La ciudad de la dirección.
     */
    public String getCiudad() {
        return ciudad;
    }

    /**
     * Establece la ciudad de la dirección.
     * 
     * @param ciudad La ciudad de la dirección.
     */
    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    /**
     * Obtiene el estado de la dirección.
     * 
     * @return El estado de la dirección.
     */
    public String getEstado() {
        return estado;
    }

    /**
     * Establece el estado de la dirección.
     * 
     * @param estado El estado de la dirección.
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }
}
