/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package boletos.entidades;

import java.time.LocalDate;
import java.util.Objects;

/**
 * Clase que representa un usuario en el sistema. Un usuario tiene atributos como
 * el ID, email, nombre, apellido, fecha de nacimiento, saldo y dirección.
 * Esta clase incluye constructores para crear instancias de usuarios con o sin el ID,
 * y métodos para acceder y modificar sus atributos.
 * 
 * @author jalt2
 */
public class Usuario {
    private Integer idUsuario;
    private String email;
    private String nombre;
    private String contrasena;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private LocalDate fechaNacimiento;
    private Double saldo;
    private Direccion direccion;

    /**
     * Constructor que recibe todos los datos del usuario, incluyendo el ID.
     * 
     * @param idUsuario El ID único del usuario.
     * @param email El correo electrónico del usuario.
     * @param nombre El nombre del usuario.
     * @param contrasena La contraseña del usuario.
     * @param apellidoPaterno El apellido paterno del usuario.
     * @param apellidoMaterno El apellido materno del usuario.
     * @param fechaNacimiento La fecha de nacimiento del usuario.
     * @param direccion La dirección del usuario.
     */
    public Usuario(Integer idUsuario, String email, String nombre, String contrasena, 
                   String apellidoPaterno, String apellidoMaterno, LocalDate fechaNacimiento, Direccion direccion) {
        this.idUsuario = idUsuario;
        this.email = email;
        this.nombre = nombre;
        this.contrasena = contrasena;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.fechaNacimiento = fechaNacimiento;
        this.direccion = direccion;
    }

    /**
     * Constructor que no recibe el ID del usuario (utilizado en el registro de un nuevo usuario).
     * 
     * @param email El correo electrónico del usuario.
     * @param nombre El nombre del usuario.
     * @param contrasena La contraseña del usuario.
     * @param apellidoPaterno El apellido paterno del usuario.
     * @param apellidoMaterno El apellido materno del usuario.
     * @param fechaNacimiento La fecha de nacimiento del usuario.
     * @param direccion La dirección del usuario.
     */
    public Usuario(String email, String nombre, String contrasena, String apellidoPaterno, 
                   String apellidoMaterno, LocalDate fechaNacimiento, Direccion direccion) {
        this.email = email;
        this.nombre = nombre;
        this.contrasena = contrasena;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.fechaNacimiento = fechaNacimiento;
        this.direccion = direccion;
    }

    /**
     * Constructor con solo el ID del usuario y la contraseña (por ejemplo, para iniciar sesión).
     * 
     * @param idUsuario El ID único del usuario.
     * @param contrasena La contraseña del usuario.
     */
    public Usuario(Integer idUsuario, String contrasena) {
        this.idUsuario = idUsuario;
        this.contrasena = contrasena;
    }

    /**
     * Obtiene el ID único del usuario.
     * 
     * @return El ID del usuario.
     */
    public Integer getIdUsuario() {
        return idUsuario;
    }

    /**
     * Establece el ID único del usuario.
     * 
     * @param idUsuario El ID del usuario.
     */
    public void setIdUsuario(Integer idUsuario) {
        this.idUsuario = idUsuario;
    }

    /**
     * Obtiene el correo electrónico del usuario.
     * 
     * @return El correo electrónico del usuario.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Establece el correo electrónico del usuario.
     * 
     * @param email El correo electrónico del usuario.
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Obtiene el nombre del usuario.
     * 
     * @return El nombre del usuario.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del usuario.
     * 
     * @param nombre El nombre del usuario.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene la contraseña del usuario.
     * 
     * @return La contraseña del usuario.
     */
    public String getContrasena() {
        return contrasena;
    }

    /**
     * Establece la contraseña del usuario.
     * 
     * @param contrasena La contraseña del usuario.
     */
    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    /**
     * Obtiene el apellido paterno del usuario.
     * 
     * @return El apellido paterno del usuario.
     */
    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    /**
     * Establece el apellido paterno del usuario.
     * 
     * @param apellidoPaterno El apellido paterno del usuario.
     */
    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    /**
     * Obtiene el apellido materno del usuario.
     * 
     * @return El apellido materno del usuario.
     */
    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    /**
     * Establece el apellido materno del usuario.
     * 
     * @param apellidoMaterno El apellido materno del usuario.
     */
    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    /**
     * Obtiene la fecha de nacimiento del usuario.
     * 
     * @return La fecha de nacimiento del usuario.
     */
    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    /**
     * Establece la fecha de nacimiento del usuario.
     * 
     * @param fechaNacimiento La fecha de nacimiento del usuario.
     */
    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    /**
     * Obtiene el saldo disponible en la cuenta del usuario.
     * 
     * @return El saldo del usuario.
     */
    public Double getSaldo() {
        return saldo;
    }

    /**
     * Establece el saldo disponible en la cuenta del usuario.
     * 
     * @param saldo El saldo del usuario.
     */
    public void setSaldo(Double saldo) {
        this.saldo = saldo;
    }

    /**
     * Obtiene la dirección del usuario.
     * 
     * @return La dirección del usuario.
     */
    public Direccion getDireccion() {
        return direccion;
    }

    /**
     * Establece la dirección del usuario.
     * 
     * @param direccion La dirección del usuario.
     */
    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }

    /**
     * Calcula el código hash del usuario basado en el ID.
     * 
     * @return El código hash del usuario.
     */
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 23 * hash + Objects.hashCode(this.idUsuario);
        return hash;
    }

    /**
     * Compara si dos usuarios son iguales basándose en sus atributos.
     * 
     * @param obj El objeto a comparar con el usuario.
     * @return true si los usuarios son iguales, false en caso contrario.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuario other = (Usuario) obj;
        return true;
    }
}
