package boletos.entidades;

import java.sql.Timestamp;

/**
 * Clase que representa un evento.
 * Un evento tiene información como el nombre, fecha, recinto, ciudad, estado y descripción.
 * 
 * @author gael_
 */
public class Evento {
    private Integer idEvento;
    private String nombre;
    private Timestamp fecha;
    private String recinto;
    private String ciudad;
    private String estado;
    private String descripcion;

    /**
     * Constructor que inicializa los atributos del evento.
     * 
     * @param idEvento El ID del evento.
     * @param nombre El nombre del evento.
     * @param fecha La fecha del evento.
     * @param recinto El recinto donde se realiza el evento.
     * @param ciudad La ciudad donde se realiza el evento.
     * @param estado El estado donde se realiza el evento.
     * @param descripcion Una descripción del evento.
     */
    public Evento(Integer idEvento, String nombre, Timestamp fecha, String recinto, String ciudad, String estado, String descripcion) {
        this.idEvento = idEvento;
        this.nombre = nombre;
        this.fecha = fecha;
        this.recinto = recinto;
        this.ciudad = ciudad;
        this.estado = estado;
        this.descripcion = descripcion;
    }

    /**
     * Obtiene el ID del evento.
     * 
     * @return El ID del evento.
     */
    public Integer getIdEvento() {
        return idEvento;
    }

    /**
     * Establece el ID del evento.
     * 
     * @param idEvento El ID del evento.
     */
    public void setIdEvento(Integer idEvento) {
        this.idEvento = idEvento;
    }

    /**
     * Obtiene el nombre del evento.
     * 
     * @return El nombre del evento.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del evento.
     * 
     * @param nombre El nombre del evento.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene la fecha del evento.
     * 
     * @return La fecha del evento.
     */
    public Timestamp getFecha() {
        return fecha;
    }

    /**
     * Establece la fecha del evento.
     * 
     * @param fecha La fecha del evento.
     */
    public void setFecha(Timestamp fecha) {
        this.fecha = fecha;
    }

    /**
     * Obtiene el recinto donde se realiza el evento.
     * 
     * @return El recinto del evento.
     */
    public String getRecinto() {
        return recinto;
    }

    /**
     * Establece el recinto donde se realiza el evento.
     * 
     * @param recinto El recinto del evento.
     */
    public void setRecinto(String recinto) {
        this.recinto = recinto;
    }

    /**
     * Obtiene la ciudad donde se realiza el evento.
     * 
     * @return La ciudad del evento.
     */
    public String getCiudad() {
        return ciudad;
    }

    /**
     * Establece la ciudad donde se realiza el evento.
     * 
     * @param ciudad La ciudad del evento.
     */
    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    /**
     * Obtiene el estado donde se realiza el evento.
     * 
     * @return El estado del evento.
     */
    public String getEstado() {
        return estado;
    }

    /**
     * Establece el estado donde se realiza el evento.
     * 
     * @param estado El estado del evento.
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * Obtiene la descripción del evento.
     * 
     * @return La descripción del evento.
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Establece la descripción del evento.
     * 
     * @param descripcion La descripción del evento.
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}

