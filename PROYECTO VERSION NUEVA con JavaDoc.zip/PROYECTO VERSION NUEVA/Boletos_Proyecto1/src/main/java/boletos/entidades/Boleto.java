package boletos.entidades;

import java.sql.Timestamp;

/**
 * Clase que representa un boleto de un evento.
 * Un boleto contiene información sobre su número de serie, fila, asiento, precio, estado,
 * evento relacionado, fecha y recinto.
 * 
 * @author gael_
 */
public class Boleto {
    private Integer idBoleto;
    private String numSerie;
    private String fila;
    private String asiento;
    private Double precio;
    private String estado;
    private String recinto;
    private String evento;
    private Timestamp fecha;

    /**
     * Constructor vacío de la clase Boleto.
     * Este constructor puede ser utilizado para crear un objeto Boleto vacío que será configurado más tarde.
     */
    public Boleto() {
        
    }

    /**
     * Constructor que inicializa todos los atributos de la clase Boleto.
     * 
     * @param idBoleto El ID del boleto.
     * @param numSerie El número de serie del boleto.
     * @param fila La fila del asiento.
     * @param asiento El número de asiento.
     * @param precio El precio del boleto.
     * @param estado El estado del boleto.
     * @param evento El evento al que corresponde el boleto.
     * @param fecha La fecha del evento.
     * @param recinto El recinto donde se lleva a cabo el evento.
     */
    public Boleto(Integer idBoleto, String numSerie, String fila, String asiento, Double precio, String estado, String evento, Timestamp fecha, String recinto) {
        this.idBoleto = idBoleto;
        this.numSerie = numSerie;
        this.fila = fila;
        this.asiento = asiento;
        this.precio = precio;
        this.estado = estado;
        this.evento = evento;
        this.fecha = fecha;
        this.recinto = recinto;
    }

    /**
     * Constructor que inicializa un boleto con ciertos atributos, útil para crear un objeto Boleto sin ID ni evento.
     * 
     * @param numSerie El número de serie del boleto.
     * @param fila La fila del asiento.
     * @param asiento El número de asiento.
     * @param precio El precio del boleto.
     * @param estado El estado del boleto.
     */
    public Boleto(String numSerie, String fila, String asiento, Double precio, String estado) {
        this.numSerie = numSerie;
        this.fila = fila;
        this.asiento = asiento;
        this.precio = precio;
        this.estado = estado;
    }

    /**
     * Obtiene el ID del boleto.
     * 
     * @return El ID del boleto.
     */
    public Integer getIdBoleto() {
        return idBoleto;
    }

    /**
     * Establece el ID del boleto.
     * 
     * @param idBoleto El ID del boleto.
     */
    public void setIdBoleto(Integer idBoleto) {
        this.idBoleto = idBoleto;
    }

    /**
     * Obtiene el número de serie del boleto.
     * 
     * @return El número de serie del boleto.
     */
    public String getNumSerie() {
        return numSerie;
    }

    /**
     * Establece el número de serie del boleto.
     * 
     * @param numSerie El número de serie del boleto.
     */
    public void setNumSerie(String numSerie) {
        this.numSerie = numSerie;
    }

    /**
     * Obtiene la fila del asiento del boleto.
     * 
     * @return La fila del asiento.
     */
    public String getFila() {
        return fila;
    }

    /**
     * Establece la fila del asiento del boleto.
     * 
     * @param fila La fila del asiento.
     */
    public void setFila(String fila) {
        this.fila = fila;
    }

    /**
     * Obtiene el número de asiento del boleto.
     * 
     * @return El número de asiento.
     */
    public String getAsiento() {
        return asiento;
    }

    /**
     * Establece el número de asiento del boleto.
     * 
     * @param asiento El número de asiento.
     */
    public void setAsiento(String asiento) {
        this.asiento = asiento;
    }

    /**
     * Obtiene el precio del boleto.
     * 
     * @return El precio del boleto.
     */
    public Double getPrecio() {
        return precio;
    }

    /**
     * Establece el precio del boleto.
     * 
     * @param precio El precio del boleto.
     */
    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    /**
     * Obtiene el estado del boleto.
     * 
     * @return El estado del boleto.
     */
    public String getEstado() {
        return estado;
    }

    /**
     * Establece el estado del boleto.
     * 
     * @param estado El estado del boleto.
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * Obtiene el evento relacionado con el boleto.
     * 
     * @return El evento relacionado con el boleto.
     */
    public String getEvento() {
        return evento;
    }

    /**
     * Establece el evento relacionado con el boleto.
     * 
     * @param evento El evento relacionado con el boleto.
     */
    public void setEvento(String evento) {
        this.evento = evento;
    }

    /**
     * Obtiene la fecha del evento.
     * 
     * @return La fecha del evento.
     */
    public Timestamp getFecha() {
        return fecha;
    }

    /**
     * Establece la fecha del evento.
     * 
     * @param fecha La fecha del evento.
     */
    public void setFecha(Timestamp fecha) {
        this.fecha = fecha;
    }

    /**
     * Obtiene el recinto donde se lleva a cabo el evento.
     * 
     * @return El recinto del evento.
     */
    public String getRecinto() {
        return recinto;
    }

    /**
     * Establece el recinto donde se lleva a cabo el evento.
     * 
     * @param recinto El recinto del evento.
     */
    public void setRecinto(String recinto) {
        this.recinto = recinto;
    }
}
