package boletos.control;

import boletos.entidades.Direccion;
import boletos.entidades.Usuario;
import boletos.persistencia.UsuariosDAO;
import boletos.presentacion.IniciarSesion;
import boletos.presentacion.RegistrarUsuario;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import javax.swing.JOptionPane;

/**
 * Controlador para el caso de uso de registro de usuarios.
 */
public class ControlRegistrarUsuario {

    private RegistrarUsuario frmRegistrarUsuario;
    private IniciarSesion frmInicioSesion;
    private UsuariosDAO usuarioDAO;

    /**
     * Constructor del controlador de registro de usuario.
     * 
     * @param usuariosDAO DAO para gestionar los usuarios.
     * @param frmIniciarSesion Referencia a la ventana de inicio de sesión.
     */
    public ControlRegistrarUsuario(UsuariosDAO usuariosDAO, IniciarSesion frmIniciarSesion) {
        this.frmInicioSesion = frmIniciarSesion;
        this.usuarioDAO = usuariosDAO;
    }

    /**
     * Inicia el caso de uso mostrando la ventana de registro de usuario.
     */
    public void iniciarCasoUso() {
        this.frmRegistrarUsuario = new RegistrarUsuario(this);
        frmRegistrarUsuario.setVisible(true);
    }

    /**
     * Registra un nuevo usuario en el sistema.
     * 
     * @param email Correo electrónico del usuario.
     * @param nombre Nombre del usuario.
     * @param contraseña Contraseña del usuario.
     * @param apellidoPaterno Apellido paterno del usuario.
     * @param apellidoMaterno Apellido materno del usuario.
     * @param fechaNacimiento Fecha de nacimiento del usuario.
     * @param calle Calle de la dirección del usuario.
     * @param ciudad Ciudad de la dirección del usuario.
     * @param estado Estado de la dirección del usuario.
     * @return true si el usuario se registró con éxito, false en caso contrario.
     */
    public boolean registrarUsuario(String email, String nombre, String contraseña, String apellidoPaterno, String apellidoMaterno, LocalDate fechaNacimiento, String calle, String ciudad, String estado) {
        // Convertir la contraseña en hash
        String contraseñaHash = generarHash(contraseña);

        if (contraseñaHash == null) {
            System.err.println("Error al generar el hash de la contraseña.");
            return false;
        }

        // Crea objetos DTO
        Direccion direccion = new Direccion(calle, ciudad, estado);
        Usuario usuario = new Usuario(email, nombre, contraseñaHash,
                apellidoPaterno, apellidoMaterno,
                fechaNacimiento, direccion);

        // Intenta registrar el usuario
        boolean registrado = usuarioDAO.registrarUsuario(usuario);

        if (registrado) {
            
            JOptionPane.showMessageDialog(null, "Usuario registrado con éxito. Ahora puedes iniciar sesión con tu id: " + usuarioDAO.obtenerIdPorEmail(email), "Registro Exitoso", JOptionPane.INFORMATION_MESSAGE);
            frmRegistrarUsuario.dispose();  
            frmInicioSesion.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Error al registrar el usuario. Inténtalo de nuevo.", "Error", JOptionPane.ERROR_MESSAGE);
        }

        return registrado;

    }

    /**
     * Genera un hash SHA-256 a partir de una cadena de entrada.
     * 
     * @param input Cadena de entrada a ser cifrada.
     * @return Cadena con el hash generado o null en caso de error.
     */
    private String generarHash(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(input.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Regresa a la pantalla de inicio de sesión.
     */
    public void regresar() {
        this.frmInicioSesion.setVisible(true);
    }

}
