package boletos.control;

import boletos.dtos.UsuarioDTO;
import boletos.entidades.Boleto;
import boletos.persistencia.BoletosDAO;
import boletos.presentacion.MenuPrincipal;
import boletos.presentacion.MisBoletos;
import boletos.presentacion.VentaBoletos;
import java.time.LocalDate;
import java.util.List;
import javax.swing.JOptionPane;

/**
 * Controlador para la venta de boletos.
 * Este controlador gestiona el flujo de la venta de boletos, mostrando formularios y confirmaciones.
 */
public class ControlVenderBoletos {
    
    private MisBoletos frmMisBoletos;
    private VentaBoletos frmVentaBoletos;
    private MenuPrincipal frmMenuPrincipal;
    private BoletosDAO boletosDAO;
    private UsuarioDTO usuarioActual;

    /**
     * Constructor de la clase ControlVenderBoletos.
     * @param frmMenuPrincipal El formulario principal del menú.
     * @param boletosDAO El acceso a los datos de los boletos.
     * @param usuarioActual El usuario actualmente autenticado.
     */
    public ControlVenderBoletos(MenuPrincipal frmMenuPrincipal, BoletosDAO boletosDAO, UsuarioDTO usuarioActual) {
        this.frmMenuPrincipal = frmMenuPrincipal;
        this.boletosDAO = boletosDAO;
        this.usuarioActual = usuarioActual;
    }
   
    /**
     * Inicia el caso de uso mostrando la ventana de "Mis Boletos".
     */
    public void iniciarCasoUso(){
        this.frmMisBoletos = new MisBoletos(this);
        frmMisBoletos.setVisible(true);
    }
    
    /**
     * Obtiene una lista de los boletos del usuario actual.
     * @return Lista de boletos asociados al usuario actual.
     */
    public List<Boleto> mostrarMisBoletos(){
        return this.boletosDAO.consultarBoletosPorUsuario(usuarioActual.getIdUsuario());
    }
    
    /**
     * Muestra un boleto específico para su venta.
     * @param id El ID del boleto.
     * @return El boleto correspondiente al ID proporcionado.
     */
    public Boleto mostrarBoletoVenta(Integer id){
        return boletosDAO.obtenerBoletoPorId(id);
    }
    
    /**
     * Inicia el proceso de venta de un boleto, mostrando la ventana correspondiente.
     * @param idBoleto El ID del boleto a vender.
     */
    public void vender(Integer idBoleto){
        frmMisBoletos.dispose();
        frmVentaBoletos = new VentaBoletos(this, idBoleto);
        frmVentaBoletos.setVisible(true);
    }
    
    /**
     * Regresa al formulario principal del menú.
     */
    public void regresar(){
        this.frmMenuPrincipal.setVisible(true);
    }
    
    /**
     * Regresa a la ventana de "Mis Boletos".
     */
    public void regresarMisBoletos(){
        this.frmMisBoletos.setVisible(true);
    }
    
    /**
     * Confirma la venta de un boleto, actualizando su estado y mostrando un mensaje al usuario.
     * @param idBoleto El ID del boleto a vender.
     * @param nuevoPrecio El nuevo precio para el boleto.
     * @param fechaLimite La fecha límite para la venta del boleto.
     */
    public void confirmarVenta(Integer idBoleto, double nuevoPrecio, LocalDate fechaLimite){
        if(boletosDAO.ponerBoletoEnVenta(idBoleto, nuevoPrecio, fechaLimite)){
            JOptionPane.showMessageDialog(frmVentaBoletos, "Boleto puesto en venta!.", "Venta", JOptionPane.INFORMATION_MESSAGE);
            frmVentaBoletos.dispose();
            this.frmMisBoletos = new MisBoletos(this);
            this.frmMisBoletos.setVisible(true);
        }
        else{
            JOptionPane.showMessageDialog(frmVentaBoletos, "No fue posible poner el boleto en venta.", "Fallo Venta", JOptionPane.INFORMATION_MESSAGE);
        }
        
    }
}
