package boletos.control;


import boletos.dtos.ActualizarUsuarioDTO;
import boletos.dtos.UsuarioDTO;
import boletos.persistencia.UsuariosDAO;
import boletos.presentacion.ActualizarUsuario;
import boletos.presentacion.MenuPrincipal;

/**
 * Clase que controla el caso de uso de actualización de usuario.
 */
public class ControlActualizarUsuario {
    private ActualizarUsuario frmActualizarUsuario;
    private UsuariosDAO usuarioDAO;
    private MenuPrincipal frmMenuPrincipal;
    private UsuarioDTO usuarioDTO;
    
    /**
     * Constructor de la clase ControlActualizarUsuario.
     * 
     * @param usuarioDAO DAO para la gestión de usuarios.
     * @param frmMenuPrincipal Referencia al menú principal.
     * @param usuarioDTO Datos del usuario a actualizar.
     */
    public ControlActualizarUsuario(UsuariosDAO usuarioDAO, MenuPrincipal frmMenuPrincipal, UsuarioDTO usuarioDTO) {
        this.frmMenuPrincipal = frmMenuPrincipal;
        this.usuarioDAO = usuarioDAO;
        this.usuarioDTO = usuarioDTO;
    }

    
    /**
     * Inicia el caso de uso para actualizar un usuario.
     */
    public void iniciarCasoUsoActualizar(){
        this.frmActualizarUsuario = new ActualizarUsuario(this);
        this.frmActualizarUsuario.setVisible(true);
        
    }
    
    /**
     * Actualiza la información de un usuario en la base de datos.
     * 
     * @param idUsuario Identificador del usuario a actualizar.
     * @param actualizarUsuarioDTO Datos actualizados del usuario.
     * @param idDireccion Identificador de la dirección del usuario.
     */
    public void actualizarUsuario(Integer idUsuario, ActualizarUsuarioDTO actualizarUsuarioDTO, Integer idDireccion){
        this.usuarioDAO.actualizarUsuario(idUsuario,actualizarUsuarioDTO, idDireccion);
    }
    
    /**
     * Obtiene el usuario actual en sesión.
     * 
     * @return Datos del usuario actual.
     */
    public UsuarioDTO getUsuarioActual() {
        return usuarioDTO;
    }
    
    /**
     * Regresa al menú principal.
     */
    public void regresar(){
        this.frmMenuPrincipal.setVisible(true);
    }
}
