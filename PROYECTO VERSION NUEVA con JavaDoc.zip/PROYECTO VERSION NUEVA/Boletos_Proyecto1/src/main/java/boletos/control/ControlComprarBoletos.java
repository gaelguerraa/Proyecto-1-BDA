package boletos.control;

import boletos.dtos.BoletoDTO;
import boletos.dtos.UsuarioDTO;
import boletos.entidades.Boleto;
import boletos.persistencia.BoletosDAO;
import boletos.presentacion.ComprarBoletosBusqueda;
import boletos.presentacion.ComprarBoletosDisponibilidad;
import boletos.presentacion.MenuPrincipal;
import java.time.LocalDate;
import java.util.List;
import javax.swing.JOptionPane;

public class ControlComprarBoletos {

    private ComprarBoletosDisponibilidad frmComprarBoletosDisponibilidad;
    private ComprarBoletosBusqueda frmComprarBoletosBusqueda;
    private BoletosDAO boletosDAO;
    private MenuPrincipal frmMenuPrincipal;
    private UsuarioDTO usuarioDTO;

    /**
     * Constructor de la clase ControlComprarBoletos.
     *
     * @param boletosDAO DAO para la gestión de boletos.
     * @param frmMenuPrincipal Referencia al menú principal.
     * @param usuarioActual Datos del usuario actual.
     */
    public ControlComprarBoletos(BoletosDAO boletosDAO, MenuPrincipal frmMenuPrincipal, UsuarioDTO usuarioActual) {
        this.boletosDAO = boletosDAO;
        this.frmMenuPrincipal = frmMenuPrincipal;
        this.usuarioDTO = usuarioActual;
    }

    /**
     * Inicia el caso de uso de compra de boletos.
     */
    public void iniciarCasoUso() {
        this.frmComprarBoletosBusqueda = new ComprarBoletosBusqueda(this);
        this.frmComprarBoletosBusqueda.setVisible(true);
    }

    /**
     * Realiza una búsqueda de boletos por nombre.
     *
     * @param nombre Nombre del evento o boleto.
     */
    public void busquedaNombre(String nombre) {
        this.frmComprarBoletosDisponibilidad = new ComprarBoletosDisponibilidad(this, nombre);
        this.frmComprarBoletosDisponibilidad.setVisible(true);
    }
    
    /**
     * Realiza una búsqueda de boletos por fecha.
     *
     * @param fecha Fecha del evento.
     */
    public void busquedaFecha(LocalDate fecha) {
        this.frmComprarBoletosDisponibilidad = new ComprarBoletosDisponibilidad(this, fecha);
        this.frmComprarBoletosDisponibilidad.setVisible(true);
    }

    /**
     * Consulta la lista de todos los boletos disponibles.
     *
     * @return Lista de boletos.
     */
    public List<Boleto> consultarListaBoletos() {
        return this.boletosDAO.consultarBoletos();
    }

    /**
     * Consulta la lista de boletos por nombre.
     *
     * @param nombre Nombre del evento o boleto.
     * @return Lista de boletos filtrados por nombre.
     */
    public List<Boleto> consultarListaBoletosNombre(String nombre) {
        return this.boletosDAO.consultarBoletosPorNombre(nombre);
    }
    
    /**
     * Consulta la lista de boletos por fecha.
     *
     * @param fecha Fecha del evento.
     * @return Lista de boletos filtrados por fecha.
     */
    public List<Boleto> consultarListaBoletosFecha(LocalDate fecha) {
        return this.boletosDAO.consultarBoletosPorFecha(fecha);
    }

    /**
     * Realiza la compra de un boleto específico.
     *
     * @param idBoleto Identificador del boleto.
     */
    public void comprarBoleto(Integer idBoleto) {
        boolean compraExitosa = this.boletosDAO.comprarBoleto(idBoleto, usuarioDTO.getIdUsuario());

        if (compraExitosa) {
            JOptionPane.showMessageDialog(frmComprarBoletosDisponibilidad, "Se compró el boleto " + idBoleto + " con éxito!", "Compra Exitosa!", JOptionPane.INFORMATION_MESSAGE);
            frmMenuPrincipal.setVisible(true);
            frmComprarBoletosDisponibilidad.dispose();
        } else {
            JOptionPane.showMessageDialog(frmComprarBoletosDisponibilidad, "El boleto " + idBoleto + " no pudo ser comprado. Será apartado durante 10 minutos.", "Fallo", JOptionPane.INFORMATION_MESSAGE);
            frmMenuPrincipal.setVisible(true);
            frmComprarBoletosDisponibilidad.dispose();
        }
    }
    
    /**
     * Verifica si el usuario ya ha comprado un boleto específico.
     *
     * @param idBoleto Identificador del boleto.
     * @return true si el usuario ya compró el boleto, false en caso contrario.
     */
    public boolean verificarCompraBoleto(Integer idBoleto) {
        return boletosDAO.verificarUsuarioAsignado(idBoleto);
    }

    /**
     * Regresa al menú principal.
     */
    public void regresar() {
        this.frmMenuPrincipal.setVisible(true);
    }
}
