package itson.boletos_proyecto1;

import boletos.control.ControlIniciarSesion;
import boletos.persistencia.ConexionBD;
import boletos.persistencia.UsuariosDAO;

/**
 * Clase principal que inicia la ejecución del programa.
 * Configura las conexiones necesarias y llama al caso de uso para iniciar sesión.
 */
public class main {

    /**
     * Método principal que ejecuta el flujo inicial del sistema.
     * Crea las instancias necesarias de las clases de conexión y control de usuarios,
     * y ejecuta el caso de uso para iniciar sesión.
     *
     * @param args Argumentos de línea de comandos, no utilizados en este caso.
     */
    public static void main(String[] args) {
        ConexionBD manejadorConexiones = new ConexionBD();
        UsuariosDAO usuarioDAO = new UsuariosDAO(manejadorConexiones);
        ControlIniciarSesion control = new ControlIniciarSesion(usuarioDAO);
        control.iniciarCasoUso();
    }

}
