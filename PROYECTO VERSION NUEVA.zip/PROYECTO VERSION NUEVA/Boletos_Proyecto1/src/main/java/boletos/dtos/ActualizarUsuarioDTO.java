package boletos.dtos;

public class ActualizarUsuarioDTO {
    private Integer idUsuario;
    private String email;
    private String nombre;
    private String hash_contrasena;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String fechaNacimiento;
    private String calle;
    private String ciudad;
    private String estado;

    public ActualizarUsuarioDTO( String email, String nombre, String apellidoPaterno, String apellidoMaterno, String fechaNacimiento,String calle, String ciudad, String estado,String hash_contrasena) {
        
        this.email = email;
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.fechaNacimiento = fechaNacimiento;
        this.calle = calle;
        this.ciudad = ciudad;
        this.estado = estado;
        this.hash_contrasena = hash_contrasena;
    }

    public Integer getIdUsuario() {
        return idUsuario;
    }

    public String getEmail() {
        return email;
    }

    public String getNombre() {
        return nombre;
    }

    public String getHash_contrasena() {
        return hash_contrasena;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }


    public String getCalle() {
        return calle;
    }

    public String getCiudad() {
        return ciudad;
    }

    public String getEstado() {
        return estado;
    }
    
}


