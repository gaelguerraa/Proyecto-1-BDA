package boletos.dtos;

public class UsuarioDTO {

    private int idUsuario;
    private String email;
    private String nombre;
    private String hashContraseña;
    private double saldo;
    private int idDireccion;

    public UsuarioDTO(int idUsuario, String email, String nombre, String hashContraseña, double saldo, int idDireccion) {
        this.idUsuario = idUsuario;
        this.email = email;
        this.nombre = nombre;
        this.hashContraseña = hashContraseña;
        this.saldo = saldo;
        this.idDireccion = idDireccion;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public String getEmail() {
        return email;
    }

    public String getNombre() {
        return nombre;
    }

    public String getHashContraseña() {
        return hashContraseña;
    }

    public double getSaldo() {
        return saldo;
    }

    public int getIdDireccion() {
        return idDireccion;
    }
}
