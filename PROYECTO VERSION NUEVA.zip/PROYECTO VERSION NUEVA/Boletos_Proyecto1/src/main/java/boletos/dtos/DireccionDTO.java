package boletos.dtos;

public class DireccionDTO {
    private Integer idDireccion;
    private String calle;
    private String ciudad;
    private String estado;

    public DireccionDTO(Integer idDireccion, String calle, String ciudad, String estado) {
        this.idDireccion = idDireccion;
        this.calle = calle;
        this.ciudad = ciudad;
        this.estado = estado;
    }

    public Integer getIdDireccion() {
        return idDireccion;
    }

    public String getCalle() {
        return calle;
    }

    public String getCiudad() {
        return ciudad;
    }

    public String getEstado() {
        return estado;
    }
    
}