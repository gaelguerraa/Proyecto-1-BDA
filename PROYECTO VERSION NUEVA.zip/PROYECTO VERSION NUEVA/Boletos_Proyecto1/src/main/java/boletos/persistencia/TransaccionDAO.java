package boletos.persistencia;

import boletos.entidades.Transaccion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.LinkedList;
import java.util.List;

public class TransaccionDAO {

    private final ConexionBD manejadorConexiones;

    public TransaccionDAO(ConexionBD manejadorConexiones) {
        this.manejadorConexiones = manejadorConexiones;
    }

//DEBE DEVOLVER TODAS LAS TRANSACCIONES
    public List<Transaccion> consularTransacciones(Integer idUsuario) {
        String codigoSQL = """
                           SELECT * FROM TRANSACCIONES WHERE idUsuario = ?;
                           """;

        List<Transaccion> listaTransacciones = new LinkedList<>();
        try {
            Connection conexion = this.manejadorConexiones.crearConexion();
            PreparedStatement comando = conexion.prepareStatement(codigoSQL);
            comando.setInt(1, idUsuario);
            ResultSet resultadosConsulta = comando.executeQuery();

            while (resultadosConsulta.next()) {
                Integer idTransaccion = resultadosConsulta.getInt("idTransaccion");
                Timestamp fechaHora = resultadosConsulta.getTimestamp("fechaHora");
                double monto = resultadosConsulta.getDouble("monto");
                String tipo = resultadosConsulta.getString("tipo");
                String estado = resultadosConsulta.getString("estado");
                Integer idBoleto = resultadosConsulta.getInt("idBoleto");
                Integer idComprador = resultadosConsulta.getInt("idComprador");
                Integer idVendedor = resultadosConsulta.getInt("idVendedor");

                Transaccion transaccion = new Transaccion(idTransaccion, fechaHora, monto, tipo, estado, idBoleto, idComprador, idVendedor);
                listaTransacciones.add(transaccion);

            }
        } catch (SQLException ex) {
            System.err.println("Error al consultar los boletos: " + ex.getMessage());
        }

        return listaTransacciones;

    }

//DEBE MOSTRAR LAS TRANSACCIONES DE LAS COMPRAS DEL USUARIO 
    public List<Transaccion> consultarCompras(Integer idUsuario) {
        String codigoSQL = """
                           SELECT 
                                                          T.idTransaccion, 
                                                          E.nombre, 
                                                          E.fecha, 
                                                          B.asiento, 
                                                          B.fila, 
                                                          B.numeroSerie, 
                                                          T.estado, 
                                                          T.monto, 
                                                          T.idVendedor,
                                                          T.idComprador,
                                                          T.tipo
                                                      FROM TRANSACCIONES T  
                                                      JOIN BOLETOS B ON T.IDBOLETO = B.IDBOLETO  
                                                      JOIN EVENTOS E ON B.IDEVENTO = E.IDEVENTO  
                                                      WHERE T.IDCOMPRADOR = ? AND tipo = "Compra";
                           """;

        List<Transaccion> listaCompras = new LinkedList<>();
        try {
            Connection conexion = this.manejadorConexiones.crearConexion();
            PreparedStatement comando = conexion.prepareStatement(codigoSQL);
            comando.setInt(1, idUsuario);
            ResultSet resultadosConsulta = comando.executeQuery();

            while (resultadosConsulta.next()) {
                Integer idTransaccion = resultadosConsulta.getInt("idTransaccion");
                String nombre = resultadosConsulta.getString("nombre");
                Timestamp fecha = resultadosConsulta.getTimestamp("fecha");
                String asiento = resultadosConsulta.getString("asiento");
                String fila = resultadosConsulta.getString("fila");
                String numeroSerie = resultadosConsulta.getString("numeroSerie");
                String estado = resultadosConsulta.getString("estado");
                Double monto = resultadosConsulta.getDouble("monto");
                String tipo = resultadosConsulta.getString("tipo");
                Integer idVendedor = resultadosConsulta.getInt("idVendedor");
                Integer idComprador = resultadosConsulta.getInt("idComprador");

                Transaccion transaccion = new Transaccion(idTransaccion, nombre, fecha, asiento, fila, numeroSerie, estado, monto, tipo, idVendedor, idComprador);

                listaCompras.add(transaccion);

            }
        } catch (SQLException ex) {
            System.err.println("Error al consultar los boletos: " + ex.getMessage());
        }

        return listaCompras;
    }

    //DEBE MOSTRAR LAS TRANSACCIONES DE LAS VENTAS DEL USUARIO 
    public List<Transaccion> consultarVentas(Integer idUsuario) {
        String codigoSQL = """
                           SELECT 
                                                          T.idTransaccion, 
                                                          E.nombre, 
                                                          E.fecha, 
                                                          B.asiento, 
                                                          B.fila, 
                                                          B.numeroSerie, 
                                                          T.estado, 
                                                          T.monto, 
                                                          T.idVendedor,
                                                          T.idComprador,
                                                          T.tipo
                                                      FROM TRANSACCIONES T  
                                                      JOIN BOLETOS B ON T.IDBOLETO = B.IDBOLETO  
                                                      JOIN EVENTOS E ON B.IDEVENTO = E.IDEVENTO  
                                                      WHERE T.IDCOMPRADOR = ? AND tipo = "Venta";
                           """;

        List<Transaccion> listaVentas = new LinkedList<>();
        try {
            Connection conexion = this.manejadorConexiones.crearConexion();
            PreparedStatement comando = conexion.prepareStatement(codigoSQL);
            comando.setInt(1, idUsuario);
            ResultSet resultadosConsulta = comando.executeQuery();

            while (resultadosConsulta.next()) {
                Integer idTransaccion = resultadosConsulta.getInt("idTransaccion");
                String nombre = resultadosConsulta.getString("nombre");
                Timestamp fecha = resultadosConsulta.getTimestamp("fecha");
                String asiento = resultadosConsulta.getString("asiento");
                String fila = resultadosConsulta.getString("fila");
                String numeroSerie = resultadosConsulta.getString("numeroSerie");
                String estado = resultadosConsulta.getString("estado");
                Double monto = resultadosConsulta.getDouble("monto");
                String tipo = resultadosConsulta.getString("tipo");
                Integer idVendedor = resultadosConsulta.getInt("idVendedor");
                Integer idComprador = resultadosConsulta.getInt("idComprador");

                Transaccion transaccion = new Transaccion(idTransaccion, nombre, fecha, asiento, fila, numeroSerie, estado, monto, tipo, idVendedor, idComprador);

                listaVentas.add(transaccion);

            }
        } catch (SQLException ex) {
            System.err.println("Error al consultar los boletos: " + ex.getMessage());
        }

        return listaVentas;
    }
}
