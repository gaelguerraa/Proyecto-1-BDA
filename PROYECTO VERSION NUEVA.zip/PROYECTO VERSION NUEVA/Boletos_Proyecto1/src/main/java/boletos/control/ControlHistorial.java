package boletos.control;

import boletos.dtos.UsuarioDTO;
import boletos.entidades.Transaccion;
import boletos.persistencia.TransaccionDAO;
import boletos.presentacion.Historial;
import boletos.presentacion.MenuPrincipal;
import java.util.List;


public class ControlHistorial {
    private Historial frmHistorial;
    private TransaccionDAO transaccionDAO;
    private MenuPrincipal frmMenuPrincipal;
    private UsuarioDTO usuarioActual;

    public ControlHistorial(TransaccionDAO transaccionDAO, MenuPrincipal frmMenuPrincipal, UsuarioDTO usuario) {
        this.transaccionDAO = transaccionDAO;
        this.frmMenuPrincipal = frmMenuPrincipal;
        this.usuarioActual = usuario;
    }
    
    public void iniciarCasoUso(){
        this.frmHistorial = new Historial(this);
        frmHistorial.setVisible(true);
    }
    
    public List<Transaccion> consultarCompras() {
        return this.transaccionDAO.consultarCompras(usuarioActual.getIdUsuario());
    }
    
    public List<Transaccion> consultarVentas() {
        return this.transaccionDAO.consultarVentas(usuarioActual.getIdUsuario());
    }
    
    public void regresar(){
        this.frmMenuPrincipal.setVisible(true);
    }
    
    
    
    
}
