package boletos.control;


import boletos.dtos.ActualizarUsuarioDTO;
import boletos.dtos.UsuarioDTO;
import boletos.persistencia.UsuariosDAO;
import boletos.presentacion.ActualizarUsuario;
import boletos.presentacion.MenuPrincipal;

public class ControlActualizarUsuario {
    private ActualizarUsuario frmActualizarUsuario;
    private UsuariosDAO usuarioDAO;
    private MenuPrincipal frmMenuPrincipal;
    private UsuarioDTO usuarioDTO;

    public ControlActualizarUsuario(UsuariosDAO usuarioDAO, MenuPrincipal frmMenuPrincipal, UsuarioDTO usuarioDTO) {
        this.frmMenuPrincipal = frmMenuPrincipal;
        this.usuarioDAO = usuarioDAO;
        this.usuarioDTO = usuarioDTO;
    }

    
    
    public void iniciarCasoUsoActualizar(){
        this.frmActualizarUsuario = new ActualizarUsuario(this);
        this.frmActualizarUsuario.setVisible(true);
        
    }
    
    public void actualizarUsuario(Integer idUsuario, ActualizarUsuarioDTO actualizarUsuarioDTO, Integer idDireccion){
        this.usuarioDAO.actualizarUsuario(idUsuario,actualizarUsuarioDTO, idDireccion);
    }
    
    public UsuarioDTO getUsuarioActual() {
        return usuarioDTO;
    }
    
    public void regresar(){
        this.frmMenuPrincipal.setVisible(true);
    }
}
