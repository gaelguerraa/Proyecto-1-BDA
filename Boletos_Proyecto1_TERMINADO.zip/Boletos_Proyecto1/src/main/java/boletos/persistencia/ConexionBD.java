package boletos.persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Clase encargada de gestionar la conexión con la base de datos.
 * Proporciona un método para establecer una conexión con la base de datos MySQL.
 */
public class ConexionBD {
    //informacion para conectarte a la bd
    private final String cadenaConexion = "jdbc:mysql://localhost/bdboletos";
    private final String usuario = "root";
    private final String contrasenia = "";
    
    /**
     * Establece una conexión con la base de datos MySQL.
     * 
     * @return Una conexión a la base de datos.
     * @throws SQLException Si ocurre un error durante la conexión.
     */
    public Connection crearConexion() throws SQLException {
        // establece conexion con el server bd
            Connection conexion = DriverManager.getConnection(cadenaConexion, usuario, contrasenia);
            return conexion;
    }
}
