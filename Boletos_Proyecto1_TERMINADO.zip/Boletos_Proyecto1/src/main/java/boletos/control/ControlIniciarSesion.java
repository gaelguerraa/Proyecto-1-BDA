package boletos.control;

import boletos.dtos.UsuarioDTO;
import boletos.persistencia.UsuariosDAO;
import boletos.presentacion.IniciarSesion;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Controlador encargado de gestionar el inicio de sesión de los usuarios.
 */
public class ControlIniciarSesion {

    private IniciarSesion frmIniciarSesion;
    private UsuariosDAO usuarioDAO;
    private UsuarioDTO usuarioActual; // Guarda el usuario que ha iniciado sesión
    
     /**
     * Constructor de la clase ControlIniciarSesion.
     * 
     * @param usuarioDAO DAO para la gestión de usuarios.
     */
    public ControlIniciarSesion(UsuariosDAO usuarioDAO){
        this.usuarioDAO = usuarioDAO;
    }
    
    /**
     * Inicia el caso de uso del inicio de sesión, mostrando la interfaz correspondiente.
     */
    public void iniciarCasoUso(){
        this.frmIniciarSesion = new IniciarSesion(this);
        this.frmIniciarSesion.setVisible(true);
    }
    
    /**
     * Permite a un usuario iniciar sesión con su ID y contraseña.
     * 
     * @param id          ID del usuario.
     * @param contraseña  Contraseña del usuario en texto plano.
     * @return {@code true} si el inicio de sesión fue exitoso, {@code false} en caso contrario.
     */
    public boolean iniciarSesion(Integer id, String contraseña) {
        UsuarioDTO usuario = usuarioDAO.obtenerUsuarioPorID(id);
        if (usuario != null && verificarHash(contraseña, usuario.getHashContraseña())) {
            usuarioActual = usuario; // Guardar el usuario que inició sesión
            return true;
        }
        return false;
    }
    
    /**
     * Verifica si la contraseña ingresada coincide con el hash almacenado.
     * 
     * @param contraseña     Contraseña ingresada por el usuario.
     * @param hashAlmacenado Hash de la contraseña almacenada en la base de datos.
     * @return {@code true} si las contraseñas coinciden, {@code false} en caso contrario.
     */
    private boolean verificarHash(String contraseña, String hashAlmacenado) {
        return hashAlmacenado.equals(generarHash(contraseña));
    }

    /**
     * Genera un hash SHA-256 a partir de una cadena de entrada.
     * 
     * @param input Cadena de texto a convertir en hash.
     * @return Hash SHA-256 en formato hexadecimal o {@code null} si ocurre un error.
     */
    private String generarHash(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(input.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Obtiene el usuario que ha iniciado sesión actualmente.
     * 
     * @return Objeto {@link UsuarioDTO} con los datos del usuario autenticado.
     */
    public UsuarioDTO getUsuarioActual() {
        return usuarioActual;
    }
} 

