package boletos.presentacion;

import boletos.control.ControlComprarBoletos;
import boletos.dtos.UsuarioDTO;
import boletos.entidades.Boleto;
import boletos.persistencia.UsuariosDAO;
import java.time.LocalDate;
import java.util.List;
import javax.swing.table.DefaultTableModel;
/**
 * Clase jFrame que muestra los boletos disponibles y filtrados
 * @author jorge
 */
public class ComprarBoletosDisponibilidad extends javax.swing.JFrame {

    private final ControlComprarBoletos control;
    private Integer idBoleto;
    private String nombreEvento;
    private LocalDate fecha;

    /**
     * @param control
     * @param nombreEvento
     */
    public ComprarBoletosDisponibilidad(ControlComprarBoletos control, String nombreEvento) {
        // Agregar un listener para la selección de filas
        this.control = control;
        this.nombreEvento = nombreEvento;
        initComponents();
        setLocationRelativeTo(null);
        this.llenarTablaBoletosNombre();
        tblBoletos.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = tblBoletos.getSelectedRow();
                if (selectedRow != -1) {
                    this.idBoleto = (int) tblBoletos.getValueAt(selectedRow, 0);
                    // AQUI OBTIENE EL ID DEL BOLETO SELECCIONADO PARA DESPUES QUE SE EJECUTE LA COMPRA
                    System.out.println(idBoleto);
                }
            }
        });
    }
    /**
     * 
     * @param control
     * @param fecha 
     */
    public ComprarBoletosDisponibilidad(ControlComprarBoletos control, LocalDate fecha) {
        this.control = control;
        this.fecha = fecha;

        setLocationRelativeTo(null);
        initComponents();
        this.llenarTablaBoletosFecha();
        tblBoletos.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = tblBoletos.getSelectedRow();
                if (selectedRow != -1) {
                    this.idBoleto = (int) tblBoletos.getValueAt(selectedRow, 0);
                }
            }
        });

    }
    /**
     * 
     */
    public void llenarTablaBoletosNombre() {
        List<Boleto> listaBoletos = this.control.consultarListaBoletosNombre(nombreEvento);

        DefaultTableModel modelo = (DefaultTableModel) this.tblBoletos.getModel();
        modelo.setRowCount(0);
        for (Boleto boleto : listaBoletos) {
            Object[] filaTabla = {
                boleto.getIdBoleto(),
                boleto.getEvento(),
                boleto.getFecha(),
                boleto.getAsiento(),
                boleto.getFila(),
                boleto.getNumSerie(),
                boleto.getEstado(),
                boleto.getPrecio()
            };
            modelo.addRow(filaTabla);
        }
    }
    /**
     * 
     */
    public void llenarTablaBoletosFecha() {
        List<Boleto> listaBoletos = this.control.consultarListaBoletosFecha(fecha);

        DefaultTableModel modelo = (DefaultTableModel) this.tblBoletos.getModel();
        modelo.setRowCount(0);
        for (Boleto boleto : listaBoletos) {
            Object[] filaTabla = {
                boleto.getIdBoleto(),
                boleto.getEvento(),
                boleto.getFecha(),
                boleto.getAsiento(),
                boleto.getFila(),
                boleto.getNumSerie(),
                boleto.getEstado(),
                boleto.getPrecio()
            };
            modelo.addRow(filaTabla);
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        panel = new javax.swing.JScrollPane();
        tblBoletos = new javax.swing.JTable();
        btnRegresar = new javax.swing.JButton();
        btnComprar1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 4, true));

        jLabel1.setBackground(new java.awt.Color(204, 204, 255));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("BOLETOS DISPONIBLES");

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));

        panel.setBackground(new java.awt.Color(204, 204, 204));
        panel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        tblBoletos.setBackground(new java.awt.Color(204, 204, 204));
        tblBoletos.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        tblBoletos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Evento", "Fecha", "Asiento", "Fila", "Serie", "Estado", "Precio"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Float.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblBoletos.getTableHeader().setReorderingAllowed(false);
        panel.setViewportView(tblBoletos);
        if (tblBoletos.getColumnModel().getColumnCount() > 0) {
            tblBoletos.getColumnModel().getColumn(0).setResizable(false);
            tblBoletos.getColumnModel().getColumn(1).setResizable(false);
            tblBoletos.getColumnModel().getColumn(3).setResizable(false);
            tblBoletos.getColumnModel().getColumn(4).setResizable(false);
            tblBoletos.getColumnModel().getColumn(5).setResizable(false);
            tblBoletos.getColumnModel().getColumn(6).setResizable(false);
            tblBoletos.getColumnModel().getColumn(7).setResizable(false);
        }

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel, javax.swing.GroupLayout.DEFAULT_SIZE, 800, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel, javax.swing.GroupLayout.DEFAULT_SIZE, 292, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        btnRegresar.setBackground(new java.awt.Color(153, 153, 153));
        btnRegresar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnRegresar.setText("REGRESAR");
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });

        btnComprar1.setBackground(new java.awt.Color(102, 102, 255));
        btnComprar1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnComprar1.setText("COMPRAR");
        btnComprar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnComprar1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnComprar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnRegresar, javax.swing.GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE))
                .addGap(322, 322, 322))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 387, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnComprar1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnRegresar)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * 
     * @param evt 
     */
    private void btnComprar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnComprar1ActionPerformed
        control.comprarBoleto(idBoleto);
    }//GEN-LAST:event_btnComprar1ActionPerformed
    /**
     * 
     * @param evt 
     */
    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        control.regresar();
        dispose();
    }//GEN-LAST:event_btnRegresarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnComprar1;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane panel;
    private javax.swing.JTable tblBoletos;
    // End of variables declaration//GEN-END:variables
}
