package boletos.presentacion;

import boletos.control.ControlActualizarUsuario;
import boletos.control.ControlComprarBoletos;
import boletos.control.ControlAgregarSaldo;
import boletos.control.ControlHistorial;
import boletos.control.ControlVenderBoletos;
import boletos.dtos.UsuarioDTO;
import boletos.persistencia.BoletosDAO;
import boletos.persistencia.ConexionBD;
import boletos.persistencia.TransaccionDAO;
import boletos.persistencia.UsuariosDAO;


/**
 * Clase jFrame que engloba todos los casos de uso disponibles
 * @author jorge
 */
public class MenuPrincipal extends javax.swing.JFrame {
    UsuarioDTO usuarioActual;
    /**
     * 
     * @param usuarioActual 
     */
    public MenuPrincipal(UsuarioDTO usuarioActual) {
        this.usuarioActual = usuarioActual;
        initComponents();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btnAgregarSaldo = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        btnComprar = new javax.swing.JButton();
        btnMisBoletos = new javax.swing.JButton();
        btnActualizarDatos = new javax.swing.JButton();
        btnHistorial = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 4, true));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("MENU PRINCIPAL");

        jPanel2.setLayout(new java.awt.GridLayout(1, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        btnAgregarSaldo.setBackground(new java.awt.Color(204, 204, 204));
        btnAgregarSaldo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnAgregarSaldo.setText("AGREGAR SALDO");
        btnAgregarSaldo.setToolTipText("");
        btnAgregarSaldo.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btnAgregarSaldo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAgregarSaldo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarSaldoActionPerformed(evt);
            }
        });

        btnSalir.setBackground(new java.awt.Color(102, 102, 255));
        btnSalir.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnSalir.setText("SALIR");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        btnComprar.setBackground(new java.awt.Color(204, 204, 204));
        btnComprar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnComprar.setText("COMPRAR");
        btnComprar.setToolTipText("");
        btnComprar.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btnComprar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnComprar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnComprarActionPerformed(evt);
            }
        });

        btnMisBoletos.setBackground(new java.awt.Color(204, 204, 204));
        btnMisBoletos.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnMisBoletos.setText("MIS BOLETOS");
        btnMisBoletos.setToolTipText("");
        btnMisBoletos.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btnMisBoletos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnMisBoletos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMisBoletosActionPerformed(evt);
            }
        });

        btnActualizarDatos.setBackground(new java.awt.Color(204, 204, 204));
        btnActualizarDatos.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnActualizarDatos.setText("ACTUALIZAR DATOS");
        btnActualizarDatos.setToolTipText("");
        btnActualizarDatos.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btnActualizarDatos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnActualizarDatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarDatosActionPerformed(evt);
            }
        });

        btnHistorial.setBackground(new java.awt.Color(204, 204, 204));
        btnHistorial.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnHistorial.setText("HISTORIAL");
        btnHistorial.setToolTipText("");
        btnHistorial.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btnHistorial.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnHistorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHistorialActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnComprar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnMisBoletos, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnAgregarSaldo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnActualizarDatos, javax.swing.GroupLayout.DEFAULT_SIZE, 568, Short.MAX_VALUE)
            .addComponent(btnHistorial, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnSalir, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnComprar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnMisBoletos, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnAgregarSaldo, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnActualizarDatos, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnHistorial, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 73, Short.MAX_VALUE)
                .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * 
     * @param evt 
     */
    private void btnComprarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnComprarActionPerformed
        ConexionBD manejadorConexiones = new ConexionBD();
        BoletosDAO boletosDAO = new BoletosDAO(manejadorConexiones);
        ControlComprarBoletos control = new ControlComprarBoletos(boletosDAO, this, usuarioActual);
        control.iniciarCasoUso();
        this.dispose();
        
    }//GEN-LAST:event_btnComprarActionPerformed
    /**
     * 
     * @param evt 
     */
    private void btnMisBoletosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMisBoletosActionPerformed
        ConexionBD manejadorConexiones = new ConexionBD();
        BoletosDAO boletosDAO = new BoletosDAO(manejadorConexiones);
        ControlVenderBoletos control = new ControlVenderBoletos(this, boletosDAO,usuarioActual);
        control.iniciarCasoUso();
        this.dispose();
    }//GEN-LAST:event_btnMisBoletosActionPerformed
    /**
     * 
     * @param evt 
     */
    private void btnActualizarDatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarDatosActionPerformed
        ConexionBD manejadorConexiones = new ConexionBD();
        UsuariosDAO usuariosDAO = new UsuariosDAO(manejadorConexiones);
        ControlActualizarUsuario control = new ControlActualizarUsuario(usuariosDAO, this, usuarioActual);
        control.iniciarCasoUsoActualizar();
        this.dispose();
    }//GEN-LAST:event_btnActualizarDatosActionPerformed
    /**
     * 
     * @param evt 
     */
    private void btnHistorialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHistorialActionPerformed
        ConexionBD manejadorConexiones = new ConexionBD();
        TransaccionDAO transaccionDAO = new TransaccionDAO(manejadorConexiones);
        ControlHistorial control = new ControlHistorial(transaccionDAO, this, usuarioActual);
        control.iniciarCasoUso();
        this.dispose();
    }//GEN-LAST:event_btnHistorialActionPerformed
    /**
     * 
     * @param evt 
     */
    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSalirActionPerformed
    /**
     * 
     * @param evt 
     */
    private void btnAgregarSaldoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarSaldoActionPerformed
        ConexionBD manejadorConexiones = new ConexionBD();
        UsuariosDAO usuariosDAO = new UsuariosDAO(manejadorConexiones);
        BoletosDAO boletosDAO = new BoletosDAO(manejadorConexiones);
        ControlAgregarSaldo control = new ControlAgregarSaldo(usuariosDAO, this, usuarioActual,boletosDAO);
        control.iniciarCasoUso();
        this.dispose();
        
    }//GEN-LAST:event_btnAgregarSaldoActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizarDatos;
    private javax.swing.JButton btnAgregarSaldo;
    private javax.swing.JButton btnComprar;
    private javax.swing.JButton btnHistorial;
    private javax.swing.JButton btnMisBoletos;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
