package boletos.entidades;

import java.sql.Timestamp;

/**
 * Clase que representa una transacción relacionada con la compra o venta de boletos.
 * La transacción puede contener información sobre el evento, el asiento, la fila, el número de serie del boleto,
 * el estado, el monto y el tipo de transacción (compra, devolución, etc.).
 * También incluye atributos históricos como fecha y hora de la transacción, ID del boleto, comprador y vendedor.
 * 
 * @author gael_
 */
public class Transaccion {
  
    private Integer idTransaccion;
    private String evento;
    private Timestamp fecha;
    private String asiento; 
    private String fila; 
    private String numeroSerie; 
    private String estado;
    private Double monto; 
    private String tipo;
    private Timestamp fechaHora;
    private Integer idBoleto;   
    private Integer idComprador; 
    private Integer idVendedor; 
    
    /**
     * Constructor con los atributos.
     * 
     * @param idTransaccion El ID de la transacción.
     * @param evento El evento relacionado con la transacción.
     * @param fecha La fecha del evento.
     * @param asiento El asiento donde se compró el boleto.
     * @param fila La fila del asiento.
     * @param numeroSerie El número de serie del boleto.
     * @param estado El estado de la transacción.
     * @param monto El monto de la transacción.
     * @param tipo El tipo de transacción (compra, devolución, etc.).
     * @param idVendedor El ID del vendedor que realizó la transacción.
     * @param idComprador El ID del comprador que realizó la transacción.
     */
    public Transaccion(Integer idTransaccion, String evento, Timestamp fecha, String asiento, String fila, 
                       String numeroSerie, String estado, Double monto, String tipo, Integer idVendedor, Integer idComprador) {
        this.idTransaccion = idTransaccion;
        this.evento = evento;
        this.fecha = fecha;
        this.asiento = asiento;
        this.fila = fila;
        this.numeroSerie = numeroSerie;
        this.estado = estado;
        this.monto = monto;
        this.tipo = tipo;
        this.idVendedor = idVendedor;
        this.idComprador = idComprador;
    }

    /**
     * Constructor con los atributos originales.
     * 
     * @param idTransaccion El ID de la transacción.
     * @param fechaHora La fecha y hora de la transacción.
     * @param monto El monto de la transacción.
     * @param tipo El tipo de transacción (compra, devolución, etc.).
     * @param estado El estado de la transacción.
     * @param idBoleto El ID del boleto.
     * @param idComprador El ID del comprador.
     * @param idVendedor El ID del vendedor.
     */
    public Transaccion(Integer idTransaccion, Timestamp fechaHora, double monto, String tipo, String estado, 
                       Integer idBoleto, Integer idComprador, Integer idVendedor) {
        this.idTransaccion = idTransaccion;
        this.fechaHora = fechaHora;
        this.monto = monto;
        this.tipo = tipo;
        this.estado = estado;
        this.idBoleto = idBoleto;
        this.idComprador = idComprador;
        this.idVendedor = idVendedor;
    }


    /**
     * Obtiene el ID de la transacción.
     * 
     * @return El ID de la transacción.
     */
    public Integer getIdTransaccion() {
        return idTransaccion;
    }

    /**
     * Establece el ID de la transacción.
     * 
     * @param idTransaccion El ID de la transacción.
     */
    public void setIdTransaccion(Integer idTransaccion) {
        this.idTransaccion = idTransaccion;
    }

    /**
     * Obtiene el evento relacionado con la transacción.
     * 
     * @return El evento de la transacción.
     */
    public String getEvento() {
        return evento;
    }

    /**
     * Establece el evento relacionado con la transacción.
     * 
     * @param evento El evento de la transacción.
     */
    public void setEvento(String evento) {
        this.evento = evento;
    }

    /**
     * Obtiene la fecha del evento relacionado con la transacción.
     * 
     * @return La fecha del evento.
     */
    public Timestamp getFecha() {
        return fecha;
    }

    /**
     * Establece la fecha del evento relacionado con la transacción.
     * 
     * @param fecha La fecha del evento.
     */
    public void setFecha(Timestamp fecha) {
        this.fecha = fecha;
    }

    /**
     * Obtiene el asiento donde se compró el boleto.
     * 
     * @return El asiento de la transacción.
     */
    public String getAsiento() {
        return asiento;
    }

    /**
     * Establece el asiento donde se compró el boleto.
     * 
     * @param asiento El asiento de la transacción.
     */
    public void setAsiento(String asiento) {
        this.asiento = asiento;
    }

    /**
     * Obtiene la fila del asiento.
     * 
     * @return La fila del asiento de la transacción.
     */
    public String getFila() {
        return fila;
    }

    /**
     * Establece la fila del asiento.
     * 
     * @param fila La fila del asiento de la transacción.
     */
    public void setFila(String fila) {
        this.fila = fila;
    }

    /**
     * Obtiene el número de serie del boleto.
     * 
     * @return El número de serie del boleto.
     */
    public String getNumeroSerie() {
        return numeroSerie;
    }

    /**
     * Establece el número de serie del boleto.
     * 
     * @param numeroSerie El número de serie del boleto.
     */
    public void setNumeroSerie(String numeroSerie) {
        this.numeroSerie = numeroSerie;
    }

    /**
     * Obtiene el estado de la transacción.
     * 
     * @return El estado de la transacción.
     */
    public String getEstado() {
        return estado;
    }

    /**
     * Establece el estado de la transacción.
     * 
     * @param estado El estado de la transacción.
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * Obtiene el monto de la transacción.
     * 
     * @return El monto de la transacción.
     */
    public Double getMonto() {
        return monto;
    }

    /**
     * Establece el monto de la transacción.
     * 
     * @param monto El monto de la transacción.
     */
    public void setMonto(Double monto) {
        this.monto = monto;
    }

    /**
     * Obtiene el tipo de transacción (compra, devolución, etc.).
     * 
     * @return El tipo de transacción.
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * Establece el tipo de transacción (compra, devolución, etc.).
     * 
     * @param tipo El tipo de transacción.
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     * Obtiene la fecha y hora de la transacción.
     * 
     * @return La fecha y hora de la transacción.
     */
    public Timestamp getFechaHora() {
        return fechaHora;
    }

    /**
     * Establece la fecha y hora de la transacción.
     * 
     * @param fechaHora La fecha y hora de la transacción.
     */
    public void setFechaHora(Timestamp fechaHora) {
        this.fechaHora = fechaHora;
    }

    /**
     * Obtiene el ID del boleto involucrado en la transacción.
     * 
     * @return El ID del boleto.
     */
    public Integer getIdBoleto() {
        return idBoleto;
    }

    /**
     * Establece el ID del boleto involucrado en la transacción.
     * 
     * @param idBoleto El ID del boleto.
     */
    public void setIdBoleto(Integer idBoleto) {
        this.idBoleto = idBoleto;
    }

    /**
     * Obtiene el ID del comprador que realizó la transacción.
     * 
     * @return El ID del comprador.
     */
    public Integer getIdComprador() {
        return idComprador;
    }

    /**
     * Establece el ID del comprador que realizó la transacción.
     * 
     * @param idComprador El ID del comprador.
     */
    public void setIdComprador(Integer idComprador) {
        this.idComprador = idComprador;
    }

    /**
     * Obtiene el ID del vendedor que realizó la transacción.
     * 
     * @return El ID del vendedor.
     */
    public Integer getIdVendedor() {
        return idVendedor;
    }

    /**
     * Establece el ID del vendedor que realizó la transacción.
     * 
     * @param idVendedor El ID del vendedor.
     */
    public void setIdVendedor(Integer idVendedor) {
        this.idVendedor = idVendedor;
    }
}
