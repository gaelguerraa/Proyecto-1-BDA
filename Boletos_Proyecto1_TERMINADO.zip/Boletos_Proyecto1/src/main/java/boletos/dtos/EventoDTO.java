package boletos.dtos;

import java.sql.Timestamp;

/**
 * DTO (Data Transfer Object) para representar la información de un evento.
 * Este objeto se utiliza para transferir los datos de un evento, incluyendo su ID,
 * nombre, fecha, recinto, ciudad, estado y descripción.
 */
public class EventoDTO {

    private Integer idEvento;
    private String nombre;
    private Timestamp fecha;
    private String recinto;
    private String ciudad;
    private String estado;
    private String descripcion;

    /**
     * Constructor de la clase EventoDTO.
     * @param idEvento El ID único del evento.
     * @param nombre El nombre del evento.
     * @param fecha La fecha del evento.
     * @param recinto El lugar o recinto donde se llevará a cabo el evento.
     * @param ciudad La ciudad donde se realizará el evento.
     * @param estado El estado de la ciudad o lugar del evento.
     * @param descripcion Una descripción breve del evento.
     */
    public EventoDTO(Integer idEvento, String nombre, Timestamp fecha, String recinto, String ciudad, String estado, String descripcion) {
        this.idEvento = idEvento;
        this.nombre = nombre;
        this.fecha = fecha;
        this.recinto = recinto;
        this.ciudad = ciudad;
        this.estado = estado;
        this.descripcion = descripcion;
    }

    /**
     * Obtiene el ID del evento.
     * @return El ID del evento.
     */
    public Integer getIdEvento() {
        return idEvento;
    }

    /**
     * Obtiene el nombre del evento.
     * @return El nombre del evento.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Obtiene la fecha del evento.
     * @return La fecha del evento.
     */
    public Timestamp getFecha() {
        return fecha;
    }

    /**
     * Obtiene el recinto donde se llevará a cabo el evento.
     * @return El recinto del evento.
     */
    public String getRecinto() {
        return recinto;
    }

    /**
     * Obtiene la ciudad donde se realiza el evento.
     * @return La ciudad del evento.
     */
    public String getCiudad() {
        return ciudad;
    }

    /**
     * Obtiene el estado de la ciudad o lugar donde se realizará el evento.
     * @return El estado del evento.
     */
    public String getEstado() {
        return estado;
    }

    /**
     * Obtiene la descripción del evento.
     * @return La descripción del evento.
     */
    public String getDescripcion() {
        return descripcion;
    }

}
