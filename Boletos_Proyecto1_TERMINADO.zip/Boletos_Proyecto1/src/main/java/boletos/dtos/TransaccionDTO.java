package boletos.dtos;

import java.sql.Timestamp;

/**
 * DTO (Data Transfer Object) que representa la información de una transacción
 * relacionada con la compra o venta de boletos. Este objeto contiene tanto los 
 * atributos actuales utilizados en las operaciones de consulta, como los atributos 
 * antiguos que se usan para un propósito más general en el sistema.
 * 
 * Los nuevos atributos incluyen detalles como el evento, fecha, asiento, número de serie,
 * estado, monto y tipo de transacción. Los atributos antiguos incluyen detalles adicionales
 * relacionados con la fecha y hora, así como los ID de boleto, comprador y vendedor.
 * 
 * @author gael_
 */
public class TransaccionDTO {

    private Integer idTransaccion;
    private String evento;  
    private Timestamp fecha;
    private String asiento;  
    private String fila;    
    private String numeroSerie; 
    private String estado; 
    private Double monto;   
    private String tipo;   
    private Timestamp fechaHora;  
    private Integer idBoleto;   
    private Integer idComprador; 
    private Integer idVendedor; 

    /**
     * Constructor con los atributos.
     * @param idTransaccion El ID único de la transacción.
     * @param evento El nombre del evento relacionado con la transacción.
     * @param fecha La fecha del evento.
     * @param asiento El asiento relacionado con la transacción.
     * @param fila La fila del asiento donde se compró el boleto.
     * @param numeroSerie El número de serie del boleto.
     * @param estado El estado de la transacción (ej. completada, cancelada).
     * @param monto El monto de la transacción.
     * @param tipo El tipo de transacción (ej. compra, devolución).
     */
    public TransaccionDTO(Integer idTransaccion, String evento, Timestamp fecha, String asiento, String fila, 
                       String numeroSerie, String estado, Double monto, String tipo) {
        this.idTransaccion = idTransaccion;
        this.evento = evento;
        this.fecha = fecha;
        this.asiento = asiento;
        this.fila = fila;
        this.numeroSerie = numeroSerie;
        this.estado = estado;
        this.monto = monto;
        this.tipo = tipo;
    }

    /**
     * Constructor con los atributos originales.
     * @param idTransaccion El ID único de la transacción.
     * @param fechaHora La fecha y hora de la transacción.
     * @param monto El monto de la transacción.
     * @param tipo El tipo de transacción.
     * @param estado El estado de la transacción.
     * @param idBoleto El ID del boleto relacionado con la transacción.
     * @param idComprador El ID del comprador de la transacción.
     * @param idVendedor El ID del vendedor de la transacción.
     */
    public TransaccionDTO(Integer idTransaccion, Timestamp fechaHora, double monto, String tipo, String estado, 
                       Integer idBoleto, Integer idComprador, Integer idVendedor) {
        this.idTransaccion = idTransaccion;
        this.fechaHora = fechaHora;
        this.monto = monto;
        this.tipo = tipo;
        this.estado = estado;
        this.idBoleto = idBoleto;
        this.idComprador = idComprador;
        this.idVendedor = idVendedor;
    }


    public Integer getIdTransaccion() {
        return idTransaccion;
    }

    public void setIdTransaccion(Integer idTransaccion) {
        this.idTransaccion = idTransaccion;
    }

    public String getEvento() {
        return evento;
    }

    public void setEvento(String evento) {
        this.evento = evento;
    }

    public Timestamp getFecha() {
        return fecha;
    }

    public void setFecha(Timestamp fecha) {
        this.fecha = fecha;
    }

    public String getAsiento() {
        return asiento;
    }

    public void setAsiento(String asiento) {
        this.asiento = asiento;
    }

    public String getFila() {
        return fila;
    }

    public void setFila(String fila) {
        this.fila = fila;
    }

    public String getNumeroSerie() {
        return numeroSerie;
    }

    public void setNumeroSerie(String numeroSerie) {
        this.numeroSerie = numeroSerie;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Double getMonto() {
        return monto;
    }

    public void setMonto(Double monto) {
        this.monto = monto;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }


    public Timestamp getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(Timestamp fechaHora) {
        this.fechaHora = fechaHora;
    }

    public Integer getIdBoleto() {
        return idBoleto;
    }

    public void setIdBoleto(Integer idBoleto) {
        this.idBoleto = idBoleto;
    }

    public Integer getIdComprador() {
        return idComprador;
    }

    public void setIdComprador(Integer idComprador) {
        this.idComprador = idComprador;
    }

    public Integer getIdVendedor() {
        return idVendedor;
    }

    public void setIdVendedor(Integer idVendedor) {
        this.idVendedor = idVendedor;
    }
}
