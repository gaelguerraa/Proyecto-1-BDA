package boletos.entidades;

public class Usuario {
    
}
